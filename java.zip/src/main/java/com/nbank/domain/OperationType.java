package com.nbank.domain;

public enum OperationType {
  BUY,
  SELL;

}
